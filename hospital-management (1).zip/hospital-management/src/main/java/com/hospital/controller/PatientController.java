package com.hospital.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.hospital.model.Patient;
import com.hospital.service.PatientService;

@RestController
@CrossOrigin
public class PatientController {

    @Autowired
    private PatientService service;

    // REGISTER
    @PostMapping("/register")
    public Patient register(@RequestBody Patient p) {
        return service.save(p);
    }

    // LOGIN ✅ (VERY IMPORTANT)
    @PostMapping("/login")
    public String login(@RequestBody Patient p) {

        Patient user = service.login(p.getEmail(), p.getPassword());

        if(user != null)
            return "Login Success ✅";
        else
            return "Invalid Email or Password ❌";
    }
}