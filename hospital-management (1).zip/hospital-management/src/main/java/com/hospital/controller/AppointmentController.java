package com.hospital.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.hospital.model.Appointment;
import com.hospital.service.AppointmentService;

@RestController
@CrossOrigin
public class AppointmentController {

    @Autowired
    private AppointmentService service;

    int queue = 1;

    @PostMapping("/book")
    public String book(@RequestBody Appointment a) {

        a.setStatus("BOOKED");
        a.setQueueNumber(queue++);
        service.save(a);

        return "Booked! Queue No: " + a.getQueueNumber();
    }

    @PostMapping("/cancel/{id}")
    public String cancel(@PathVariable int id) {

        Appointment a = service.getById(id);

        if(a != null){
            a.setStatus("CANCELLED");
            service.save(a);
            return "Cancelled";
        }

        return "Appointment Not Found";
    }

    @GetMapping("/appointments")
    public List<Appointment> getAll() {
        return service.getAll();
    }
}