package com.hospital.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.hospital.model.Doctor;
import com.hospital.service.DoctorService;

@RestController
@CrossOrigin
public class DoctorController {

    @Autowired
    private DoctorService service;

    @PostMapping("/addDoctor")
    public Doctor addDoctor(@RequestBody Doctor d) {
        return service.save(d);
    }

    // ✅ NEW (ADMIN VIEW)
    @GetMapping("/doctors")
    public List<Doctor> getDoctors() {
        return service.getAll();
    }
}