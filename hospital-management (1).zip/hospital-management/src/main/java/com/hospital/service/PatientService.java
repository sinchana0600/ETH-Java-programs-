package com.hospital.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.hospital.model.Patient;
import com.hospital.repository.PatientRepository;

@Service
public class PatientService {

    @Autowired
    private PatientRepository repo;

    public Patient save(Patient p) {
        return repo.save(p);
    }

    public Patient login(String email, String password) {
        return repo.findByEmailAndPassword(email, password);
    }
}