package com.hospital.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.hospital.model.Doctor;
import com.hospital.repository.DoctorRepository;

@Service
public class DoctorService {

    @Autowired
    private DoctorRepository repo;

    public Doctor save(Doctor d) {
        return repo.save(d);
    }

    public List<Doctor> getAll() {
        return repo.findAll();
    }
}