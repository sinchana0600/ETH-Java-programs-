package com.hospital.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.hospital.model.Appointment;
import com.hospital.repository.AppointmentRepository;

@Service
public class AppointmentService {

    @Autowired
    private AppointmentRepository repo;

    public Appointment save(Appointment a) {
        return repo.save(a);
    }

    public List<Appointment> getAll() {
        return repo.findAll();
    }

    public Appointment getById(int id) {
        return repo.findById(id).orElse(null);
    }
}